# Open_Domain_Question_Answer
Question answering (QA) is a computer science discipline within the fields of information retrieval and natural language processing (NLP), which is concerned with building
systems that automatically answer questions posed by humans in a natural language. To accomplish this, we will use a Python library and TensorFlow wrapper that makes deep
learning and AI
Open-ended Open Questionnaire (OpenQA) is an important function in Natural Language Processing (NLP), which aims to answer a question in a natural language based on large informal 
texts.
Natural language processing (NLP) refers back to the branch of laptop science—and more specifically, the branch of synthetic intelligence or AI—concerned with giving computers the 
capability to understand textual content and spoken phrases in lots the equal way human beings can.
Sub – domain Open-domain Question Answering
